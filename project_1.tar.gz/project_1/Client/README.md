# cse461-Projects
Boqiang Cui (boqiang)
Andy Phan (aphan1)
Omkar Agashe (omagashe)

# Instructions to run:

Set the SERVER_IP and PORT_NUM fields to what you want.
 
Run these commands:

javac Client.java

java Client