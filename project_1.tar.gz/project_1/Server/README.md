# cse461-Projects
Boqiang Cui (boqiang)
Andy Phan (aphan1)
Omkar Agashe (omagashe)

# Instructions to run:

Modify server port as necessary. Then,

Run these commands:

javac Server.java

javac ServerThread.java

java Server

